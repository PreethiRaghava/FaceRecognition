need to download this predefined models before running the file 


dlib_face_recognition_resnet_model_v1.dat
shape_predictor_68_face_landmarks.dat